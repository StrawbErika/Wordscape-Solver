export default
    [
        11,
        ['E', 'R', 'R', 'A', 'C', 'H'],
        [
            [[" ", true], [" ", true], [" ", true], ["A", false], [" ", true], [" ", true], ["R", false], ["A", false], ["C", false], ["E", false], [" ", true]],
            [[" ", true], [" ", true], [" ", true], ["R", false], [" ", true], [" ", true], ["A", false], [" ", true], ["A", false], [" ", true], ["A", false]],
            [[" ", true], ["H", false], [" ", true], ["C", false], ["H", false], ["A", false], ["R", false], [" ", true], ["R", false], [" ", true], ["R", false]],
            [["E", false], ["A", false], ["C", false], ["H", false], [" ", true], [" ", true], ["E", false], [" ", true], ["E", false], [" ", true], ["C", false]],
            [[" ", true], ["R", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["H", false]],
            [["H", false], ["E", false], ["A", false], ["R", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["E", false]],
            [[" ", true], [" ", true], [" ", true], ["E", false], [" ", true], [" ", true], ["R", false], ["A", false], ["C", false], ["E", false], ["R", false]],
            [[" ", true], [" ", true], [" ", true], ["A", false], ["C", false], ["H", false], ["E", false], [" ", true], ["A", false], [" ", true], [" ", true]],
            [[" ", true], [" ", true], [" ", true], ["R", false], [" ", true], [" ", true], ["A", false], ["C", false], ["R", false], ["E", false], [" ", true]],
            [[" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["C", false], [" ", true], ["E", false], [" ", true], [" ", true]],
            [[" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["H", false], [" ", true], ["R", false], [" ", true], [" ", true]],
        ],
        [
            ["ARCH", [0, 3], [1, 3], [2, 3], [3, 3]],
            ["HARE", [2, 1], [3, 1], [4, 1], [5, 1]],
            ["EACH", [3, 0], [3, 1], [3, 2], [3, 3]],
            ["HEAR", [5, 0], [5, 1], [5, 2], [5, 3]],
            ["REAR", [5, 3], [6, 3], [7, 3], [8, 3]],
            ["ACHE", [7, 3], [7, 4], [7, 5], [7, 6]],
            ["RACER", [6, 6], [6, 7], [6, 8], [6, 9], [6, 10]],
            ["REACH", [6, 6], [7, 6], [8, 6], [9, 6], [10, 6]],
            ["ACRE", [8, 6], [8, 7], [8, 8], [8, 9]],
            ["CARER", [6, 8], [7, 8], [8, 8], [9, 8], [10, 8]],
            ["ARCHER", [1, 10], [2, 10], [3, 10], [4, 10], [5, 10], [6, 10]],
            ["CARE", [0, 8], [1, 8], [2, 8], [3, 8]],
            ["CHAR", [2, 3], [2, 4], [2, 5], [2, 6]],
            ["RACE", [0, 6], [0, 7], [0, 8], [0, 9]],
            ["RARE", [0, 6], [1, 6], [2, 6], [3, 6]],
        ]
    ];

