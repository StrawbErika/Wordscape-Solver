export default
    [
        11,
        ['I', 'I', 'E', 'E', 'T', 'D', 'S'],
        [
            [[" ", true], [" ", true], ["S", false], ["E", false], ["E", false], ["D", false], [" ", true], [" ", true], ["S", false], [" ", true], [" ", true]],
            [[" ", true], [" ", true], ["I", false], [" ", true], [" ", true], ["I", false], [" ", true], ["T", false], ["I", false], ["E", false], ["D", false]],
            [[" ", true], [" ", true], ["T", false], [" ", true], [" ", true], ["E", false], [" ", true], [" ", true], ["D", false], [" ", true], ["E", false]],
            [["T", false], ["I", false], ["E", false], ["S", false], [" ", true], ["T", false], ["I", false], ["D", false], ["E", false], [" ", true], ["I", false]],
            [["E", false], [" ", true], [" ", true], ["I", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["T", false]],
            [["E", false], ["D", false], ["I", false], ["T", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["I", false]],
            [["S", false], [" ", true], [" ", true], ["E", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["E", false]],
            [[" ", true], [" ", true], [" ", true], ["D", false], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], [" ", true], ["S", false]],
        ],
        [
            ["SEED", [0, 2], [0, 3], [0, 4], [0, 5]],
            ["SITE", [0, 2], [1, 2], [2, 2], [3, 2]],
            ["TIE", [3, 0], [3, 1], [3, 2], [3, 3]],
            ["TEES", [3, 0], [4, 0], [5, 0], [6, 0]],
            ["TEES", [3, 0], [4, 0], [5, 0], [6, 0]],
            ["EDIT", [5, 0], [5, 1], [5, 2], [5, 3]],
            ["SITED", [3, 3], [4, 3], [5, 3], [6, 3], [7, 3]],
            ["DIET", [0, 5], [1, 5], [2, 5], [3, 5]],
            ["TIDE", [3, 5], [3, 6], [3, 7], [3, 8]],
            ["SIDE", [0, 8], [1, 8], [2, 8], [3, 8]],
            ["TIED", [1, 7], [1, 8], [1, 9], [1, 10]],
            ["DEITIES", [1, 10], [2, 10], [3, 10], [4, 10], [5, 10], [6, 10], [7, 10]],
        ]
    ];

