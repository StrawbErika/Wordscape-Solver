GALVEZ, JUAN MIGUEL
NEPOMUCENO, ERIKA LOUISE
VILLARO, PAUL

ElectronJS: JavaScript, HTML, CSS

Set up: 
Download zip
Npm install

How to run: 
Npm start
